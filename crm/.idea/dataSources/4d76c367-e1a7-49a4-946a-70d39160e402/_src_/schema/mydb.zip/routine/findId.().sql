CREATE PROCEDURE findId(OUT ph INT)
  BEGIN
SELECT Bid into ph from t_stu_book;
END;
