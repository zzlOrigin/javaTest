CREATE VIEW v_book AS
  SELECT
    `mydb`.`t_book`.`isbn`     AS `isbn`,
    `mydb`.`t_book`.`bookname` AS `bookname`
  FROM `mydb`.`t_book`;
