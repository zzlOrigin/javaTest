CREATE VIEW v_student_book AS
  SELECT
    `b`.`bookname` AS `bookname`,
    `s`.`name`     AS `name`
  FROM `mydb`.`t_book` `b`
    JOIN `mydb`.`t_stu_book` `sb`
    JOIN `mydb`.`t_student` `s`
  WHERE ((`sb`.`Stuid` = `s`.`id`) AND (`b`.`id` = `sb`.`Bid`));
