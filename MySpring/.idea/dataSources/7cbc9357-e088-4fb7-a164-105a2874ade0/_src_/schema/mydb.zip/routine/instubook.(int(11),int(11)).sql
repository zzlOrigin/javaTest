CREATE PROCEDURE instubook(IN bid INT, IN stuid INT)
  BEGIN
INSERT INTO t_stu_book (Bid,Stuid) VALUES (bid,stuid);
END;
