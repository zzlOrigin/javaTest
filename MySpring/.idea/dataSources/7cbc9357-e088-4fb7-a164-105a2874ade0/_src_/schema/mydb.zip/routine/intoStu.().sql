CREATE PROCEDURE intoStu()
  BEGIN
INSERT INTO t_stu_book (Bid,Stuid) VALUES (2,3);
END;
